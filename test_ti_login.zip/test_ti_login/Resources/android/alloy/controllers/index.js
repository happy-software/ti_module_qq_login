function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function doClick() {
        alert($.label.text);
    }
    function go_to_qq_login() {
        win = Ti.UI.createWindow({
            backgroundColor: "yellow"
        });
        win.open();
        proxy = login_module.createLogin({
            backgroundColor: "red",
            width: 100,
            height: 100,
            top: 50,
            left: 50
        });
        proxy.addEventListener("click", function() {
            console.info("==== proxy was clicked");
            login_module.showWeixinLoginPage("qq", function() {
                console.info("=== in error");
            }, function() {
                console.info("=== in success");
            }, function() {
                console.info("=== in cancel");
            });
            console.info("==== end : proxy was clicked");
        });
        win.add(proxy);
        console.info("== hi:" + login_module.name);
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "index";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.index = Ti.UI.createWindow({
        backgroundColor: "white",
        id: "index"
    });
    $.__views.index && $.addTopLevelView($.__views.index);
    $.__views.label = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#000",
        font: {
            fontSize: 12
        },
        text: "Hello, World",
        id: "label"
    });
    $.__views.index.add($.__views.label);
    doClick ? $.__views.label.addEventListener("click", doClick) : __defers["$.__views.label!click!doClick"] = true;
    $.__views.my_button = Ti.UI.createButton({
        title: "QQ 登陆",
        top: "20",
        id: "my_button"
    });
    $.__views.index.add($.__views.my_button);
    go_to_qq_login ? $.__views.my_button.addEventListener("click", go_to_qq_login) : __defers["$.__views.my_button!click!go_to_qq_login"] = true;
    $.__views.my_button = Ti.UI.createButton({
        title: "QQ 登陆",
        top: "20",
        id: "my_button"
    });
    $.__views.index.add($.__views.my_button);
    go_to_qq_login ? $.__views.my_button.addEventListener("click", go_to_qq_login) : __defers["$.__views.my_button!click!go_to_qq_login"] = true;
    exports.destroy = function() {};
    _.extend($, $.__views);
    $.index.open();
    __defers["$.__views.label!click!doClick"] && $.__views.label.addEventListener("click", doClick);
    __defers["$.__views.my_button!click!go_to_qq_login"] && $.__views.my_button.addEventListener("click", go_to_qq_login);
    __defers["$.__views.my_button!click!go_to_qq_login"] && $.__views.my_button.addEventListener("click", go_to_qq_login);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;