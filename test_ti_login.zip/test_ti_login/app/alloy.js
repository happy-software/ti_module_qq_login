//
// Alloy.Globals.someGlobalFunction = function(){};

login_module = require('com.happysoft.login');
console.info('== login_module is: ' )
console.info(login_module)
