function doClick(e) {
    alert($.label.text);
}

function go_to_qq_login(e){
  win = Ti.UI.createWindow({
    backgroundColor: 'yellow'
  })
  win.open();
  proxy = login_module.createLogin({
    backgroundColor: 'red',
    width: 100,
    height: 100,
    top: 50,
    left: 50
  })
  proxy.addEventListener('click', function(e){
    console.info('==== proxy was clicked')
    login_module.showWeixinLoginPage('qq', function(){
      console.info('=== in error');

    },function(){
      console.info('=== in success');
    },function(){
      console.info('=== in cancel');
    } );
    console.info('==== end : proxy was clicked')
  })
  //proxy.addEventListener('click', function(e){
  //  console.info('==== proxy was clicked')
  //  login_module.showWeixinLoginPage('lalala', function(){
  //    console.info('=== in error');
  //  },function(){
  //    console.info('=== in success');
  //  },function(){
  //    console.info('=== in cancel');
  //  })
  //  console.info('==== end proxy was clicked')
  //})
  win.add(proxy)
  console.info('== hi:' + login_module.name)
}

$.index.open();
